import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// PWA Manifest dynamic creation via Blob URL
const manifest = {
  name: "Shahad Dashboard",
  short_name: "Shahad",
  description: "Personal Productivity & Finance Dashboard",
  start_url: window.location.origin,
  display: "standalone",
  background_color: "#0a0a0a",
  theme_color: "#1a1a1a",
  icons: [
    {
      src: "/icon.svg",
      sizes: "512x512",
      type: "image/svg+xml",
      purpose: "any maskable"
    }
  ]
};

const blob = new Blob([JSON.stringify(manifest)], { type: 'application/json' });
const manifestURL = URL.createObjectURL(blob);
const link = document.createElement('link');
link.rel = 'manifest';
link.href = manifestURL;
document.head.appendChild(link);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
