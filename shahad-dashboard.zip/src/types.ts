export interface Transaction {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'income' | 'expense';
}

export interface HabitData {
  [date: string]: boolean;
}

export interface DashboardState {
  transactions: Transaction[];
  habits: HabitData;
}
