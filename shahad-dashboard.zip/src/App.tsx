/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { 
  Plus, 
  Minus, 
  Trash2, 
  Calendar as CalendarIcon, 
  Wallet, 
  CheckCircle2, 
  TrendingUp, 
  TrendingDown,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Transaction, HabitData } from './types';

const STORAGE_KEY = 'zenith_dashboard_data';

export default function App() {
  // State
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [habits, setHabits] = useState<HabitData>({});
  const [currentDate, setCurrentDate] = useState(new Date());
  
  // Form State
  const [desc, setDesc] = useState('');
  const [amount, setAmount] = useState('');
  const [amountError, setAmountError] = useState(false);
  const [type, setType] = useState<'income' | 'expense'>('expense');

  // Load Data
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setTransactions(parsed.transactions || []);
        setHabits(parsed.habits || {});
      } catch (e) {
        console.error("Failed to load data", e);
      }
    }
  }, []);

  // Save Data
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({ transactions, habits }));
  }, [transactions, habits]);

  // Calculations
  const totalBalance = useMemo(() => {
    return transactions.reduce((acc, t) => {
      return t.type === 'income' ? acc + t.amount : acc - t.amount;
    }, 0);
  }, [transactions]);

  const totalIncome = useMemo(() => 
    transactions.filter(t => t.type === 'income').reduce((acc, t) => acc + t.amount, 0)
  , [transactions]);

  const totalExpense = useMemo(() => 
    transactions.filter(t => t.type === 'expense').reduce((acc, t) => acc + t.amount, 0)
  , [transactions]);

  // Habit Calculations
  const daysInMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0).getDate();
  const monthKey = `${currentDate.getFullYear()}-${currentDate.getMonth()}`;
  
  const habitsThisMonth = useMemo(() => {
    let count = 0;
    for (let i = 1; i <= daysInMonth; i++) {
      const dateStr = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${i}`;
      if (habits[dateStr]) count++;
    }
    return count;
  }, [habits, currentDate, daysInMonth]);

  const habitProgress = (habitsThisMonth / daysInMonth) * 100;

  const streak = useMemo(() => {
    let currentStreak = 0;
    const today = new Date();
    let checkDate = new Date(today);
    
    while (true) {
      const dateStr = `${checkDate.getFullYear()}-${checkDate.getMonth() + 1}-${checkDate.getDate()}`;
      if (habits[dateStr]) {
        currentStreak++;
        checkDate.setDate(checkDate.getDate() - 1);
      } else {
        // If today isn't checked, check yesterday to see if streak is still alive
        if (currentStreak === 0) {
          checkDate.setDate(checkDate.getDate() - 1);
          const yesterdayStr = `${checkDate.getFullYear()}-${checkDate.getMonth() + 1}-${checkDate.getDate()}`;
          if (habits[yesterdayStr]) {
             // Streak exists but today isn't done yet
             // We'll continue the loop from yesterday
             continue;
          }
        }
        break;
      }
    }
    return currentStreak;
  }, [habits]);

  // Handlers
  const addTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!desc || !amount) return;

    const newTransaction: Transaction = {
      id: crypto.randomUUID(),
      date: new Date().toLocaleDateString('en-CA'), // YYYY-MM-DD in local time
      description: desc,
      amount: parseFloat(amount),
      type
    };

    setTransactions([newTransaction, ...transactions]);
    setDesc('');
    setAmount('');
    setAmountError(false);
  };

  const handleAmountKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    // Allow: backspace, delete, tab, escape, enter, decimal point
    if ([8, 46, 9, 27, 13, 110, 190].indexOf(e.keyCode) !== -1 ||
        // Allow: Ctrl+A, Command+A
        (e.keyCode === 65 && (e.ctrlKey === true || e.metaKey === true)) ||
        // Allow: home, end, left, right, down, up
        (e.keyCode >= 35 && e.keyCode <= 40)) {
             return;
    }
    // Ensure that it is a number and stop the keypress
    if ((e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) && (e.keyCode < 96 || e.keyCode > 105)) {
        e.preventDefault();
    }
  };

  const handleAmountPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const pasteData = e.clipboardData.getData('text');
    if (!/^\d*\.?\d*$/.test(pasteData)) {
      e.preventDefault();
      setAmountError(true);
      setTimeout(() => setAmountError(false), 3000);
    }
  };

  const deleteTransaction = (id: string) => {
    setTransactions(transactions.filter(t => t.id !== id));
  };

  const toggleHabit = (day: number) => {
    const dateStr = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${day}`;
    setHabits(prev => ({
      ...prev,
      [dateStr]: !prev[dateStr]
    }));
  };

  const changeMonth = (offset: number) => {
    const newDate = new Date(currentDate.getFullYear(), currentDate.getMonth() + offset, 1);
    setCurrentDate(newDate);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white p-4 md:p-8 font-sans">
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Header Section */}
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-1">
            <h1 className="text-3xl font-bold tracking-tight">Shahad Dashboard</h1>
            <p className="text-zinc-400 flex items-center gap-2">
              <CalendarIcon size={16} />
              {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </p>
          </div>

          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full md:w-auto bg-zinc-900 border border-zinc-800 p-6 rounded-2xl shadow-xl flex items-center gap-6"
          >
            <div className="p-3 bg-blue-500/10 rounded-xl">
              <Wallet className="text-blue-500" size={24} />
            </div>
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-zinc-500">Total Balance</p>
              <h2 className={`text-3xl font-bold ${totalBalance >= 0 ? 'text-blue-400' : 'text-rose-400'}`}>
                ${totalBalance.toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </h2>
            </div>
          </motion.div>
        </header>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Panel: Money Tracker */}
          <section className="lg:col-span-7 space-y-6">
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 shadow-sm">
              <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
                <TrendingUp className="text-blue-500" size={20} />
                Money Tracker
              </h3>

              {/* Add Transaction Form */}
              <form onSubmit={addTransaction} className="grid grid-cols-1 sm:grid-cols-12 gap-4 mb-8">
                <div className="sm:col-span-5">
                  <input 
                    type="text" 
                    placeholder="Description (e.g. Salary, Coffee)"
                    className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all"
                    value={desc}
                    onChange={(e) => setDesc(e.target.value)}
                  />
                </div>
                <div className="sm:col-span-3 relative">
                  <input 
                    type="number" 
                    placeholder="Amount"
                    step="0.01"
                    inputMode="decimal"
                    className={`w-full bg-zinc-950 border ${amountError ? 'border-rose-500' : 'border-zinc-800'} rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all`}
                    value={amount}
                    onKeyDown={handleAmountKeyDown}
                    onPaste={handleAmountPaste}
                    onChange={(e) => {
                      setAmount(e.target.value);
                      if (amountError) setAmountError(false);
                    }}
                  />
                  <AnimatePresence>
                    {amountError && (
                      <motion.div 
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 10 }}
                        className="absolute -bottom-6 left-0 text-[10px] font-bold text-rose-500 uppercase tracking-wider"
                      >
                        Numbers only, please!
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
                <div className="sm:col-span-3 flex bg-zinc-950 border border-zinc-800 rounded-xl p-1">
                  <button 
                    type="button"
                    onClick={() => setType('income')}
                    className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${type === 'income' ? 'bg-blue-500 text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
                  >
                    Income
                  </button>
                  <button 
                    type="button"
                    onClick={() => setType('expense')}
                    className={`flex-1 py-2 rounded-lg text-xs font-bold transition-all ${type === 'expense' ? 'bg-rose-500 text-white' : 'text-zinc-500 hover:text-zinc-300'}`}
                  >
                    Expense
                  </button>
                </div>
                <div className="sm:col-span-1">
                  <button 
                    type="submit"
                    className="w-full h-full bg-zinc-100 text-black rounded-xl flex items-center justify-center hover:bg-white transition-colors"
                  >
                    <Plus size={20} />
                  </button>
                </div>
              </form>

              {/* Transaction List */}
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="text-zinc-500 text-xs uppercase tracking-widest border-b border-zinc-800">
                      <th className="pb-4 font-semibold">Date</th>
                      <th className="pb-4 font-semibold">Item</th>
                      <th className="pb-4 font-semibold text-right">Amount</th>
                      <th className="pb-4 font-semibold text-right"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-zinc-800/50">
                    <AnimatePresence initial={false}>
                      {transactions.length === 0 ? (
                        <tr>
                          <td colSpan={4} className="py-12 text-center text-zinc-500 italic">
                            No transactions yet. Start tracking your wealth!
                          </td>
                        </tr>
                      ) : (
                        transactions.map((t) => (
                          <motion.tr 
                            key={t.id}
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, scale: 0.95 }}
                            className="group hover:bg-zinc-800/30 transition-colors"
                          >
                            <td className="py-4 text-sm text-zinc-400 font-mono">{t.date}</td>
                            <td className="py-4 font-medium">{t.description}</td>
                            <td className={`py-4 text-right font-bold ${t.type === 'income' ? 'text-blue-400' : 'text-rose-400'}`}>
                              {t.type === 'income' ? '+' : '-'}${t.amount.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                            </td>
                            <td className="py-4 text-right">
                              <button 
                                onClick={() => deleteTransaction(t.id)}
                                className="p-2 text-zinc-600 hover:text-rose-500 transition-colors opacity-0 group-hover:opacity-100"
                              >
                                <Trash2 size={16} />
                              </button>
                            </td>
                          </motion.tr>
                        ))
                      )}
                    </AnimatePresence>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-blue-500/10 rounded-lg">
                    <TrendingUp className="text-blue-500" size={16} />
                  </div>
                  <span className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Monthly Income</span>
                </div>
                <p className="text-2xl font-bold text-blue-400">${totalIncome.toLocaleString()}</p>
              </div>
              <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl">
                <div className="flex items-center gap-3 mb-2">
                  <div className="p-2 bg-rose-500/10 rounded-lg">
                    <TrendingDown className="text-rose-500" size={16} />
                  </div>
                  <span className="text-xs font-bold text-zinc-500 uppercase tracking-widest">Monthly Expenses</span>
                </div>
                <p className="text-2xl font-bold text-rose-400">${totalExpense.toLocaleString()}</p>
              </div>
            </div>
          </section>

          {/* Right Panel: Habit Calendar */}
          <section className="lg:col-span-5 space-y-6">
            <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 shadow-sm h-full">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold flex items-center gap-2">
                  <CheckCircle2 className="text-emerald-500" size={20} />
                  Habit Tracker
                </h3>
                <div className="flex items-center gap-3 bg-emerald-500/10 px-4 py-2 rounded-full border border-emerald-500/20">
                  <span className="text-xs font-bold text-emerald-500 uppercase tracking-widest">Streak</span>
                  <span className="text-xl font-black text-emerald-400">{streak}</span>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mb-8 space-y-2">
                <div className="flex justify-between text-xs font-bold uppercase tracking-widest text-zinc-500">
                  <span>Monthly Progress</span>
                  <span className="text-emerald-400">{Math.round(habitProgress)}%</span>
                </div>
                <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${habitProgress}%` }}
                    className="h-full bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]"
                  />
                </div>
              </div>

              {/* Calendar Header */}
              <div className="flex items-center justify-between mb-6">
                <h4 className="text-lg font-semibold">
                  {currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                </h4>
                <div className="flex gap-2">
                  <button 
                    onClick={() => changeMonth(-1)}
                    className="p-2 hover:bg-zinc-800 rounded-lg transition-colors"
                  >
                    <ChevronLeft size={20} />
                  </button>
                  <button 
                    onClick={() => changeMonth(1)}
                    className="p-2 hover:bg-zinc-800 rounded-lg transition-colors"
                  >
                    <ChevronRight size={20} />
                  </button>
                </div>
              </div>

              {/* Calendar Grid */}
              <div className="grid grid-cols-7 gap-2">
                {['S', 'M', 'T', 'W', 'T', 'F', 'S'].map((day, i) => (
                  <div key={`${day}-${i}`} className="text-center text-[10px] font-bold text-zinc-600 mb-2 uppercase">
                    {day}
                  </div>
                ))}
                
                {/* Empty slots for first day offset */}
                {Array.from({ length: new Date(currentDate.getFullYear(), currentDate.getMonth(), 1).getDay() }).map((_, i) => (
                  <div key={`empty-${i}`} className="aspect-square" />
                ))}

                {/* Days of month */}
                {Array.from({ length: daysInMonth }).map((_, i) => {
                  const day = i + 1;
                  const dateStr = `${currentDate.getFullYear()}-${currentDate.getMonth() + 1}-${day}`;
                  const isChecked = habits[dateStr];
                  const isToday = new Date().toDateString() === new Date(currentDate.getFullYear(), currentDate.getMonth(), day).toDateString();

                  return (
                    <button
                      key={day}
                      onClick={() => toggleHabit(day)}
                      className={`
                        aspect-square rounded-lg flex items-center justify-center text-sm font-medium transition-all relative
                        ${isChecked 
                          ? 'bg-emerald-500 text-white shadow-[0_0_15px_rgba(16,185,129,0.3)]' 
                          : 'bg-zinc-800/50 text-zinc-500 hover:bg-zinc-800 hover:text-zinc-300'}
                        ${isToday ? 'ring-2 ring-blue-500/50 ring-offset-2 ring-offset-[#0a0a0a]' : ''}
                      `}
                    >
                      {day}
                      {isChecked && (
                        <motion.div 
                          layoutId="check"
                          className="absolute inset-0 bg-emerald-500 rounded-lg flex items-center justify-center"
                        >
                          <Plus size={16} className="rotate-45" />
                        </motion.div>
                      )}
                    </button>
                  );
                })}
              </div>

              <div className="mt-8 p-4 bg-zinc-800/30 rounded-xl border border-zinc-800/50">
                <p className="text-xs text-zinc-400 leading-relaxed">
                  <span className="text-emerald-400 font-bold">Tip:</span> Consistency is key. Even checking off one small habit every day builds a powerful momentum over time.
                </p>
              </div>
            </div>
          </section>

        </div>
      </div>
    </div>
  );
}
